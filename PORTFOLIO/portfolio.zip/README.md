# Joncarter
Beautiful HTML,CSS and Bootstrap Portfolio

# Demo
- https://joncarter.netlify.app/

# Clone Project
- https://github.com/SA7MAN/joncarter

# Features
- Fully Responsive
- Mobile Navigations
- Animated elements on scroll
- Smooth scrolling in each section.
- Sticky Navigation on scrolling
- and more ..


# Credit
- https://fonts.google.com/
- https://line-awesome.com/
- https://unsplash.com/
- https://michalsnik.github.io/aos/


# Watch more
For more videos visit to my YouTube channel. [SA7MAN](https://www.youtube.com/c/SA7MAN)
